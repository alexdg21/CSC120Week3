﻿using System;
namespace W2
{
    public class AndGates
    {


        public static bool InPut(bool x, bool y)
        {
            //if (x == false && y == false)
            {
            //    return false;
            }
            //if (x.Equals(false) && y.Equals(true))
            {
            //    return false;
            }
            //if (x.Equals(true)
            //    && y.Equals(false))
            {
            //    return false;
            }
            //if (x.Equals(true)
            // && y.Equals(true))
            {//
             //  return true;
             //}
             //  return false;
                return x && y;
            }
        }

    }
}